// main.js - Lógica principal

const btnTema = document.getElementById("btnTema");

if (btnTema) {
  const temaSalvo = localStorage.getItem("tema") || "light";
  aplicarTema(temaSalvo);

  btnTema.addEventListener("click", () => {
    const temaAtual = document.documentElement.getAttribute("data-bs-theme");
    const novoTema = temaAtual === "dark" ? "light" : "dark";
    aplicarTema(novoTema);
    localStorage.setItem("tema", novoTema);
  });
}

function aplicarTema(tema) {
  document.documentElement.setAttribute("data-bs-theme", tema);
  const btn = document.getElementById("btnTema");
  if (btn) {
    btn.textContent = `Tema: ${tema === "dark" ? "Dark" : "Light"}`;
  }
}
