// ui.js - Manipulação da interface

let totalCarrinho = 0;

function adicionarAoCarrinho(inputId, delta) {
  const input = document.getElementById(inputId);
  if (!input) return;

  const valorAtual = parseInt(input.value) || 0;
  const novoValor = Math.max(0, valorAtual + delta);
  input.value = novoValor;

  totalCarrinho += delta;
  if (totalCarrinho < 0) totalCarrinho = 0;

  const spanTotal = document.getElementById("total-carrinho");
  if (spanTotal) {
    spanTotal.textContent = totalCarrinho;
  }
}
