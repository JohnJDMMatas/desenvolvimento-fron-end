// api.js - Consumo de APIs externas

async function carregarDepoimentos() {
  try {
    const response = await fetch(
      "https://jsonplaceholder.typicode.com/comments?_limit=3"
    );
    const depoimentos = await response.json();

    const container = document.getElementById("depoimentos");
    if (!container) return;

    depoimentos.forEach((dep) => {
      const card = document.createElement("div");
      card.className = "col";
      card.innerHTML = `
        <div class="card h-100">
          <div class="card-body">
            <h6 class="card-title">${dep.name}</h6>
            <p class="card-text text-muted small">${dep.body}</p>
            <small class="text-muted">${dep.email}</small>
          </div>
        </div>
      `;
      container.appendChild(card);
    });
  } catch (error) {
    console.error("Erro ao carregar depoimentos:", error);
  }
}

// Auto-preenchimento via ViaCEP
const inputCep = document.getElementById("cep");
if (inputCep) {
  inputCep.addEventListener("blur", async () => {
    const cep = inputCep.value.replace(/\D/g, "");
    if (cep.length !== 8) return;

    try {
      const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const data = await response.json();
      if (data.erro) return;

      document.getElementById("uf").value = data.uf || "";
      document.getElementById("cidade").value = data.localidade || "";
      document.getElementById("bairro").value = data.bairro || "";
      document.getElementById("logradouro").value = data.logradouro || "";
    } catch (err) {
      console.error("Erro ao buscar CEP:", err);
    }
  });
}
